Move the software to folder "run\App".
Then edit open.bat (in run folder) and change the code to "start yourprogram.exe".

Now run launch.bat and ENJOY!